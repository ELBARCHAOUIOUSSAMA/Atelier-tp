package com.xproce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EazyBankBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
